// Stub auth service for build
export const authService = {
  async getUserPermissions(userId: string) {
    return [];
  },
  async checkPermission(userId: string, permission: string) {
    return false;
  }
};

export default authService;